You must first install the required libraries:

pip install -r requirements.txt


You build your party with

python3 setup.py sdist

result file in dist/timedependentparty-X.Y.Z.tar.gz
