from timedependentparty.TimeDependentParty import TimeDependentParty

def party():
    return TimeDependentParty