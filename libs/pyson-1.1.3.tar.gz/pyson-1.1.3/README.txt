A simple jackson-style serializer but for and in python.
Limited annotation possibilities.

build with

python3 setup.py sdist

result file in dist/blabla.tar.gz
