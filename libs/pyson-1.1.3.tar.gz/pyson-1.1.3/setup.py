from setuptools import setup

setup(
    name='pyson',
    version='1.1.3',    
    description='annotation mechanism for json serialization',
    url='https://tracinsy.ewi.tudelft.nl/pubtrac/Utilities/packson',
    author='W.Pasman',
    #packages={'src':'*'},
    packages = ['pyson'],
    package_data = { 'pyson': ['py.typed'] },
    install_requires=[ "uri@https://tracinsy.ewi.tudelft.nl/pubtrac/Utilities/export/297/uri/dist/uri-2.0.0.tar.gz"],

    classifiers=[
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9'
    ],
)