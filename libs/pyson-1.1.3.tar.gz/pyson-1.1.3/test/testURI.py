
import unittest

from uri.uri import URI

from pyson.JsonValue import JsonValue, getJsonValue


class testURI(unittest.TestCase):
	def testURI(self):
		uristr = 'ws://localhost:8080/profilesserver/websocket/get/party/party1'
		self.assertEqual(uristr,str(URI(uristr)))